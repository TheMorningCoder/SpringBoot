package com.weather.forecast.api.model.request;

import com.weather.forecast.api.model.Coord;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class City {

    private Long cityId;
}
