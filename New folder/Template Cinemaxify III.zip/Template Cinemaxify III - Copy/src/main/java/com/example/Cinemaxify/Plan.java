package com.example.Cinemaxify;

public interface Plan {
    String getPlanName();
}
