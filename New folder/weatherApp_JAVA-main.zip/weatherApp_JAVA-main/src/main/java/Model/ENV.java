package Model;

public class ENV {
    public static final String API_KEY = "zoBKNORyQhUgZwlYOO3FDaiNsi4ztGhg";
    public static final String OneDayForecast_URL = "http://dataservice.accuweather.com/forecasts/v1/daily/1day/";
}
