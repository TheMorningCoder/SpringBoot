package Model;

public class Country {
}
