# weatherApp_JAVA
Java program that displays the weather of a city using Accuweather API.
