package com.example.seat_booking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
