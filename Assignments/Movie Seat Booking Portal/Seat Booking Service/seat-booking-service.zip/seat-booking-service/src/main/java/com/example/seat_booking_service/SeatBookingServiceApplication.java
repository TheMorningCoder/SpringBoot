package com.example.seat_booking_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeatBookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeatBookingServiceApplication.class, args);
	}

}
